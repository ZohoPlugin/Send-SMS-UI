/* $Id$ */

ZPluginM360 = function() {};

ZPluginM360.init = function() {

	$(".sendbtn").click(function(){
		$('#sendsms_form').submit() //No I18N
	});

	$(".cancelbtn").click(function() { //No I18N
		window.close();
	});

	$("#sendsms_form").submit(function() { //No I18N

		var validationStatus = ZPluginM360.validateFields();
		if (!validationStatus) {
			return false;
		}

		var message=$("#message").val();
		var fromno=$("#fromnums").val();
		var recipients_list = $(".recipient-numbers");
		var rec_numbers = "";
		for (var i=0; i< recipients_list.length; i++) {
			var recNum = $(recipients_list[i]).val();
			if (recNum.trim() != "") {
				rec_numbers += recNum + ",";
			}
		}

		$(".sendbtn").val("Sending...");

		var formData = new FormData();
		formData.append('from_no', fromno); //No I18N
		formData.append('to_no', rec_numbers); //No I18N
		formData.append('message', message); //No I18N
		formData.append(csrfNAME, ZPluginUtil.getCsrfTokenFromCookie(csrfCookieName)); //No I18

		$.ajax({
			url : "/plugin/message360/handler?action=sendsms", //No I18N
			type: "POST", //No I18N
			processData: false,
			contentType: false,
			data : formData,
			dataType: "json", //No I18N
			success:function(obj) {
				if (obj.status == "success") {
					//alert("SMS successfully sent."); //No I18N
                    if (obj.total == 1) {
                            if(obj.success == 1){
                            	var button_obj = {};
            					button_obj.id = 'done';
            					button_obj.text = js_obj.plugin_docusign_done;
            					button_obj.primary = true;
            					button_obj.callback = function() {
            						window.close();
            					};
            					
            					var btn_list = [];
            					btn_list.push(button_obj);
            					
                                ZPluginDialog.showSuccessPopup(js_obj.plugin_message360_successgreat, js_obj.plugin_message360_successmsg, btn_list);  
                            }
                            else {
                            	$(".sendbtn").val("Send");
                            	if (obj.failurelist.length > 0) {
                            		ZPluginM360.addErrorMsg("send_error", obj.failurelist[0].msg); //No I18N
                            	}
                            	else {
                            		ZPluginM360.addErrorMsg("send_error", js_obj.plugin_message360_errormsg); //No I18N
                            	}
                            }
                    }
                    else{
                            ZPluginDialog.showSMSReportPopup(obj);   
                    }
				}
				else {
					$(".sendbtn").val("Send");
					ZPluginM360.addErrorMsg("server_error", js_obj.plugin_message360_servererror); //No I18N
				}
			},
			error: function() {
				$(".sendbtn").val("Send");
				ZPluginM360.addErrorMsg("server_error",  js_obj.plugin_message360_servererror); //No I18N
			}
		});
	});

	$("#insert_fields").change(function() {
		var sel_val = $(this).val();
		if (sel_val !== "select") {
			var msg = $("#message").val();
			$("#message").val(msg + sel_val);
		}
	});

	$("#add_recipient").click(function() {
		if ($('#dialog').length == 0) {
			$('body').append('<div id="dialog" style="display:none;">'); //No I18N
		}

		var screenWidth;
		var screenHeight;

		var buttonObj = {}
		buttonObj.Add = function() {
			var recipientType = $('#rec_type').val();
			if (recipientType === 'MobileNumber') {
				var recipientName = $('#rec_name').val();
				var recipientNumber = $('#rec_number').val();

				if (recipientNumber.trim() == "") {
					alert(js_obj.plugin_message360_entermobilenum); 
					return;
				}

				var recRow = '<tr class="dataRow"><td>'+recipientName+'</td><td>'+recipientNumber+'<input type="hidden" value="'+recipientNumber+'" class="recipient-numbers"/></td><td><a href="javascript:void(0)" onclick="ZPluginM360.removeRecipientRow(this);">'+js_obj.plugin_message360_remove+'</a></td></tr>';

				$("#recipientsList").append(recRow);

				$(this).dialog('close');
			}
			else {
				var selectedRecId = $('#rec_lookup_id').val();

				if (selectedRecId.trim() === "") {
					alert(js_obj.plugin_message360_crmrecord); 
					return;
				}

				var dialogObj = this;

				$.ajax({
					url : "/plugin/message360/handler?action=getMobileForRecord&module="+recipientType+"&rec_id="+selectedRecId, //No I18N
					type: "GET", //No I18N
					dataType: "json", //No I18N
					success:function(obj) {
						if (obj.mobile != "") {
							var recipientName = $("#rec_lookup_name").val();
							var recipientNumber = obj.mobile;

							var recRow = '<tr class="dataRow"><td>'+recipientName+'</td><td>'+recipientNumber+'<input type="hidden" value="'+(recipientType+'#'+selectedRecId+'#'+recipientNumber)+'" class="recipient-numbers"/></td><td><a href="javascript:void(0)" onclick="ZPluginM360.removeRecipientRow(this);">'+js_obj.plugin_message360_remove+'</a></td></tr>';

							$("#recipientsList").append(recRow);

							$(dialogObj).dialog('close');
						}
						else {
							alert(js_obj.plugin_message360_updatemobilenum); 
						}
					},
					error: function() {
						$(dialogObj).dialog('close');
					}
				});
			}
		};
		buttonObj.Cancel = function() {
			$(this).dialog('close');
		};

		var dialogHtml = '<table class="form-style-1"><tbody><tr id="rec_row"><td><select id="rec_type"><option value="MobileNumber">'+js_obj.plugin_message360_mobilenum+'</option><option value="Contacts">'+js_obj.plugin_message360_contact+'</option><option value="Leads">'+js_obj.plugin_message360_lead+'</option></select></td><td><input type="text" id="rec_name" maxlength="100" placeholder="Enter name here" style="width: 180px;"><div style="display:none" id="rec_lookup"><input tabindex="1" type="text" id="rec_lookup_name" width="180px" disabled="disabled"/><input type="hidden" id="rec_lookup_id"/><img src="/images/spacer.gif" width="17" height="19" class="lookup recipient-lookup"></div></td><td><input type="text" id="rec_number" maxlength="15" placeholder="Enter mobile number here" style="width: 180px;"></td></tr></tbody></table>';
		if (sendsms_from_crm_record) {
			if (moduleName === "Leads") {
				dialogHtml = '<table class="form-style-1"><tbody><tr id="rec_row"><td><select id="rec_type"><option value="Leads">'+js_obj.plugin_message360_lead+'</option></select></td><td><div id="rec_lookup"><input tabindex="1" type="text" id="rec_lookup_name" width="180px" disabled="disabled"/><input type="hidden" id="rec_lookup_id"/><img src="/images/spacer.gif" width="17" height="19" class="lookup recipient-lookup"></div></td><td></td></tr></tbody></table>';
			}
			else if (moduleName === "Contacts") {
				dialogHtml = '<table class="form-style-1"><tbody><tr id="rec_row"><td><select id="rec_type"><option value="Contacts">'+js_obj.plugin_message360_contact+'</option></select></td><td><div id="rec_lookup"><input tabindex="1" type="text" id="rec_lookup_name" width="180px" disabled="disabled"/><input type="hidden" id="rec_lookup_id"/><img src="/images/spacer.gif" width="17" height="19" class="lookup recipient-lookup"></div></td><td></td></tr></tbody></table>';
			}
		}
		ZPluginDialog.showCommonDialog('Add Recipient',true,'dialog',buttonObj,[((screenWidth-(screenWidth/1.47))/1.02),((screenHeight-(screenHeight/1.327))/1.9)],600,true,'auto',false); //No I18N

		$('#dialog').empty();
		$('#dialog').append(dialogHtml);

		$(".recipient-lookup").click(function() {
			ZPluginUtil.openCRMLookup($('#rec_type').val(), function(data) {
				var fldId = data.fldId;
				var fldName = data.fldName;
				
				$('#rec_lookup_id').val(fldId);
				$('#rec_lookup_name').val(fldName);
			});
		});
		
		$("#rec_name").focus();

		$("#rec_type").change(function() {
			var sel_val = $(this).val();
			if (sel_val == "MobileNumber") {
				$("#rec_lookup").hide();
				$("#rec_name").show();
				$("#rec_number").show();
				$("#rec_name").focus();
			}
			else {
				$("#rec_name").hide();
				$("#rec_number").hide();
				$("#rec_lookup").show();
				$("#rec_lookup_name").val('');
				$("#rec_lookup_id").val('');

				if (sel_val == "Leads") {
					$("#rec_lookup_name").attr('placeholder', js_obj.plugin_message360_crmlead);
				}
				else {
					$("#rec_lookup_name").attr('placeholder', js_obj.plugin_message360_crmcontact);
				}
			}
		});
	});


	$("#sms_template").change(function() {
		var sel_val = $(this).val();
		if (sel_val === "createnew") {
			var redirectUrl = location.href;	
			location.href = "/plugin/message360/handler?action=newtemplate&module="+moduleName+"&redirect_url="+encodeURIComponent(redirectUrl);
		}
		else if (sel_val !== "none") {
			var templateMsg = templates[sel_val].message;
			$("#message").val(templateMsg);
		}
	});
};

ZPluginM360.removeRecipientRow = function(elm) {
	var trElm = $(elm).closest('tr');
	var confirmStatus = confirm("Are you sure want to delete this recipient?"); 
	if (confirmStatus) {
		$(trElm).remove();
	}
};

ZPluginM360.validateFields = function() {
	ZPluginM360.hideErrorMsg();

	var validationStatus = true;

	var recipients_list = $(".recipient-numbers");
	if (recipients_list.length == 0) {
		ZPluginM360.addErrorMsg("recipient_missing", "Please add at least one recipient"); //No I18N
		validationStatus = false;
	}

	var message = $("#message").val();
	if (message.trim() == "") {
		ZPluginM360.addErrorMsg("msg_missing", "Please enter message."); //No I18N
		validationStatus = false;
	}

	return validationStatus;
};

ZPluginM360.addErrorMsg = function(id, msg) {
	if ($("#error_msg").is(':visible') == false) {
                $('#error_msg').show();
		$('html, body').animate({scrollTop: $('#error_msg').offset().top}, 100);
        }
	$('#errors').append('<li id="'+id+'">'+msg+'</li>');
};

ZPluginM360.removeErrorMsg = function(id) {
	$('#'+id).remove();
	if ($('#errors').children().length == 0) {
		$('#error_msg').hide();
	}
};

ZPluginM360.hideErrorMsg = function() {
	$('#errors').children().remove();
	$('#error_msg').hide();
};

ZPluginM360.initNewTemplatePage = function() {
	
	if (moduleName == "Leads") {
		$("#contact_insert_fields").hide();
		$("#lead_insert_fields").show();
	}
	else {
		$("#lead_insert_fields").hide();
		$("#contact_insert_fields").show();
	}
	
	$("#crm_module").change(function() {
		var sel_val = $(this).val();
		
		if (sel_val === "Contacts") {
			$("#lead_insert_fields").hide();
			$("#contact_insert_fields").show();
		}
		else {
			$("#contact_insert_fields").hide();
			$("#lead_insert_fields").show();
		}
	});
	
	$(".sendbtn").click(function(){
		$('#sms_template_form').submit() //No I18N
	});

	$(".cancelbtn").click(function() { //No I18N
		if (redirectUrl.trim() != "") {
			location.href = redirectUrl;
		}
		else {
			window.close();
		}
	});

	$("#sms_template_form").submit(function() { //No I18N

		var validationStatus = ZPluginM360.validateTemplateFields();
		if (!validationStatus) {
			return false;
		}

		var template_name = $("#template_name").val();
		var template_for = $("#crm_module").val();
		var template_message = $("#template_message").val();

		$(".sendbtn").val("Saving...");

		var formData = new FormData();
		formData.append('template_for', template_for); //No I18N
		formData.append('template_name', template_name); //No I18N
		formData.append('template_message', template_message); //No I18N
		formData.append(csrfNAME, ZPluginUtil.getCsrfTokenFromCookie(csrfCookieName)); //No I18

		$.ajax({
			url : "/plugin/message360/handler?action=savetemplate", //No I18N
			type: "POST", //No I18N
			processData: false,
			contentType: false,
			data : formData,
			dataType: "json", //No I18N
			success:function(obj) {
				$(".sendbtn").val("Save");
				if (obj.status == "success") {
					if (redirectUrl.trim() != "") {
						if (redirectUrl.indexOf("#") != -1) {
                            redirectUrl = redirectUrl.substring(0, redirectUrl.indexOf("#"));
						}
						if (redirectUrl.indexOf("?") != -1) {
							location.href = redirectUrl + "&template_id="+obj.template_id;
						}
						else {
							location.href = redirectUrl + "?template_id="+obj.template_id;
						}
					}
					else {
						alert("SMS Template saved successfully."); 
						window.close();
					}
				}
				else {
					if (obj.code == "duplicate") {
						ZPluginM360.addErrorMsg("server_error", "Already template exists with this name, please try different name."); //No I18N
					}
					else {
						ZPluginM360.addErrorMsg("server_error", "Unable to save SMS template, please try again later."); //No I18N
					}
				}
			},
			error: function() {
				$(".sendbtn").val("Save");
				ZPluginM360.addErrorMsg("server_error", "Unable to save SMS template, please try again later."); //No I18N
			}
		});
	});

	$("#lead_insert_fields").change(function() {
		var sel_val = $(this).val();
		if (sel_val !== "select") {
			var msg = $("#template_message").val();
			$("#template_message").val(msg + sel_val);
		}
	});
	$("#contact_insert_fields").change(function() {
		var sel_val = $(this).val();
		if (sel_val !== "select") {
			var msg = $("#template_message").val();
			$("#template_message").val(msg + sel_val);
		}
	});
};

ZPluginM360.validateTemplateFields = function() {
	ZPluginM360.hideErrorMsg();

	var validationStatus = true;

	var template_name = $("#template_name").val();
	if (template_name.trim() === "") {
		ZPluginM360.addErrorMsg("template_name_missing", "Please enter template name."); //No I18N
		validationStatus = false;
	}

	var template_message = $("#template_message").val();
	if (template_message.trim() == "") {
		ZPluginM360.addErrorMsg("template_name_missing", "Please enter template message."); //No I18N
		validationStatus = false;
	}

	return validationStatus;
};

ZPluginM360.enableInboundSMS = function(phone, enable) {
	
	var formData = new FormData();
	formData.append('phone', phone); //No I18N
	formData.append('type', 'inboundsms'); //No I18N
	formData.append('val', enable); //No I18N
	formData.append(csrfNAME, ZPluginUtil.getCsrfTokenFromCookie(csrfCookieName)); //No I18

	$.ajax({
		url : "/plugin/message360/handler?action=updateconf", //No I18N
		type: "POST", //No I18N
		processData: false,
		contentType: false,
		data : formData,
		dataType: "json", //No I18N
		success:function(obj) {
		}
	});
};

ZPluginM360.postOnFeed = function(phone, postonfeed) {
	
	var formData = new FormData();
	formData.append('phone', phone); //No I18N
	formData.append('type', 'postonfeed'); //No I18N
	formData.append('val', postonfeed); //No I18N
	formData.append(csrfNAME, ZPluginUtil.getCsrfTokenFromCookie(csrfCookieName)); //No I18

	$.ajax({
		url : "/plugin/message360/handler?action=updateconf", //No I18N
		type: "POST", //No I18N
		processData: false,
		contentType: false,
		data : formData,
		dataType: "json", //No I18N
		success:function(obj) {
		}
	});
};

ZPluginM360.initSMSCampaignPage = function() {

	$("#contact_sms_template").change(function() {
		var sel_val = $(this).val();
		if (sel_val !== "none") {
			var templateMsg = contact_templates[sel_val].message;
			$("#message").val(templateMsg);
		}
	});

	$("#lead_sms_template").change(function() {
		var sel_val = $(this).val();
		if (sel_val !== "none") {
			var templateMsg = lead_templates[sel_val].message;
			$("#message").val(templateMsg);
		}
	});

	$("#sendsms").click(function(){
   	 	var fromno = $("#fromnumber").val();
   	 	var member_status = $("#stat").val();
   	 	var leadsms = $("#contactmsg").val();
   	 	var contactsms = $("#leadmsg").val();   	

		$(".sendbtn").val("Sending...");

		var formData = new FormData();
		formData.append('from_no', fromno); //No I18N
		formData.append('campaign_id', campaign_id); //No I18N
		formData.append('contact_msg', contactsms); //No I18N
		formData.append('lead_msg', leadsms); //No I18N
		formData.append('status', member_status); //No I18N
		formData.append(csrfNAME, ZPluginUtil.getCsrfTokenFromCookie(csrfCookieName)); //No I18

		$.ajax({
			url : "/plugin/message360/handler?action=sendsmscampaign", //No I18N
			type: "POST", //No I18N
			processData: false,
			contentType: false,
			data : formData,
			dataType: "json", //No I18N
			success:function(obj) {
				if (obj.status == "success") {
					alert(js_obj.plugin_message360_smssent); 
					window.close();
				}
				else {
					$(".sendbtn").val("Send");
					ZPluginM360.addErrorMsg("server_error", js_obj.plugin_message360_servererror); //No I18N
				}
			},
			error:function(){
				$(".sendbtn").val("Send");
				ZPluginM360.addErrorMsg("server_error", js_obj.plugin_message360_servererror); //No I18N
			}
		});
	});
};
